
def getLine():
    sentence = input("Enter sentence to spellcheck: ")
    sentence = sentence.split(" ")
    return sentence


def readFromFile():
    with open("EnglishWords.txt") as myFile:
        words = myFile.read().split("\n")
    return words


def spellcheck():
    words = readFromFile()
    sentence = getLine()

    for userWord in sentence:
        inDict = False
        for word in words:
            if word == userWord:
                inDict = True
        if inDict:
            print(userWord," spelt correctly")
        else:
            print(userWord," not found in dictionary")

spellcheck()
