A simple Game Over background image.

Licensed under CC0 (see: LICENSE.txt)

Asset sources:
- Longsword by LordNeo (CC0): https://opengameart.org/node/10879
- Ferrum Extra-Condensed font by Sora Sagano (CC0): https://fontlibrary.org/en/font/ferrum
